import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import dotenv from "dotenv";
import User from "./models/User.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;
const MONGO = process.env.MONGO_URI || "";

mongoose.connect(MONGO)
  .then(() => console.log("MongoDB connected ✅"))
  .catch(err => console.error("MongoDB error:", err.message));

app.post("/generate-key", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });
    const apiKey = "dev_" + Math.random().toString(36).substring(2, 12);
    const user = await User.findOneAndUpdate(
      { email },
      { apiKey },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );
    return res.json({ success: true, apiKey: user.apiKey });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Server error" });
  }
});

app.get("/", (req, res) => res.json({ status: "anondevx-portal backend running" }));

app.listen(PORT, () => console.log(`Server running on port ${PORT} 🚀`));
